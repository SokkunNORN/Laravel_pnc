
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Comment</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>
    
    <?php echo $__env->yieldContent('content'); ?>

    <script src="<?php echo e(url('js/app.js')); ?>"></script>
    
    <script>
        // delete modal
        $('#deleteModal').on('show.bs.modal', function(event) {
             var button = $(event.relatedTarget);
             var id = button.data('id')
             console.log('id ' + id);
             var modal = $(this)
             var url = "<?php echo e(url('comments')); ?>/" + id;
             $('#mDelete').attr('action', url);
             console.log(url);
        })

        // show modal
        $('#showModal').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget);
            var id = button.data('id')
            var body = button.data('body')
            var created = button.data('created')
            console.log('id ' + id);
            console.log('body ' + body);
            console.log('create ' + created);
            var modal = $(this)
            modal.find('#created').text(created);
            modal.find('#body').text(body);
        })

        // edit modal
        $('#editModal').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget);
            var id = button.data('id')
            var body = button.data('body')
            console.log('id ' + id);
            console.log('body ' + body);
            var modal = $(this)
            modal.find('#body').text(body);
             var url = "<?php echo e(url('comments')); ?>/" + id;
             $('#mUpdate').attr('action', url);
             console.log(url);
        })

        $("#dModal, #aModal, #uModal").fadeTo(5000, 500).slideUp();

    </script>
</body>
</html>