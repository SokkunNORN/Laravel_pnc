<?php $__env->startSection('content'); ?>

<div class="container mt-4">
    <a href="<?php echo e(route('comments.index')); ?>" title="Go back" class="text-primary">
        <i class="material-icons">arrow_back</i>
    </a>
    <hr>
    <div class="card shadow-sm">
        <div class="card-body">
            <div class="text-right"><small><?php echo e($data->created_at->diffForHumans()); ?></small></div>
            <p><?php echo e($data->body); ?></p>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.blog', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>