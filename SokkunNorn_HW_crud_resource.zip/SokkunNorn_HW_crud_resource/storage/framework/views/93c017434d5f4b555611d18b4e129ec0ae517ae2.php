<?php $__env->startSection('content'); ?>

<div class="container mt-4">
    <div class="row">
        <div class="col-3"></div>
        <div class="col-6">
            <div class="card shadow-sm">
                <div class="card-header">
                    <div class="row">
                        <div class="col-3">
                            <a href="<?php echo e(url('comments')); ?>" title="Go back" class="text-primary">
                                <i class="material-icons">arrow_back</i>
                            </a>
                        </div>
                        <div class="col-6 text-center">
                            <h4>Edit Comment</h4>
                        </div>
                        <div class="col-3"></div>
                    </div>
                </div> 
                <div class="card-body">

                    
                    <form action="<?php echo e(route('comments.update', $data)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("put"); ?>
                        <div class="form-group">
                            <textarea placeholder="Comment" name="body" 
                                style="resize: none;" 
                                cols="30" 
                                rows="10"
                                class="form-control"><?php echo e($data->body); ?></textarea>
                        </div>
                        <div class="form-group">
                            <button class="btn btn-primary btn-block">
                                Update Comment
                            </button>
                        </div>
                    </form>

                </div> 
            </div> 
        </div>
        <div class="col-3"></div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.blog', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>