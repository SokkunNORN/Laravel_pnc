     

<?php $__env->startSection('content'); ?>
         
    <div class="jumbotron">
        <h1 class="text-center display-1">Comment</h1>
    </div>
<div class="container mt-4">
    
    <a href="#" data-toggle="modal" data-target="#addModal" class="text-primary" title="Add Comment">
        <i class="material-icons">control_point</i>
    </a>
    <hr>

    
    
    <?php if(session('delete')): ?>
        <div class="alert alert-danger alert-dismissible fade show" id="dModal" role="alert">
            <?php echo e(session('delete')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    
    <?php if(session('update')): ?>
        <div class="alert alert-success alert-dismissible fade show" id="uModal" role="alert">
            <?php echo e(session('update')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    
    <?php if(session('add')): ?>
        <div class="alert alert-primary alert-dismissible fade show" id="aModal" role="alert">
            <?php echo e(session('add')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    

    <?php if($comment != ""): ?>
        <?php $__currentLoopData = $comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card">
                <div class="card-body">
                    <p><?php echo e($item->body); ?></p>
                </div>
                <div class="card-footer">
                    <div class="text-right">
                        
                        <a href="#" data-toggle="modal" data-target="#showModal" data-id="<?php echo e($item->id); ?>"
                            data-body="<?php echo e($item->body); ?>"  data-created="<?php echo e($item->created_at->diffForHumans()); ?>" 
                            class="text-success" title="View Comment">
                            <i class="material-icons">visibility</i>
                        </a>
                        
                        <a href="#"  data-toggle="modal" data-target="#editModal" 
                            data-id="<?php echo e($item->id); ?>" data-body="<?php echo e($item->body); ?>"
                            class="text-primary" title="Edit Comment">
                            <i class="material-icons">edit</i>
                        </a>
                        <a href="#" class="text-danger" data-toggle="modal" data-id="<?php echo e($item->id); ?>"
                            data-target="#deleteModal" title="Delete Comment">
                            <i class="material-icons">delete</i>
                        </a>
                    </div>
                </div>
            </div> 
            <br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        
        
        
        <div class="modal fade" id="addModal" tabindex="-1" role="dialog" >
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Add Comment!</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo e(route('comments.store')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <textarea placeholder="Comment" name="body" 
                                    style="resize: none;" 
                                    cols="30" 
                                    rows="10"
                                    required
                                    class="form-control"></textarea>
                            </div>
                            <div class="form-group">
                                <button type="button" class="btn btn-secondary" style="width: 49.6%;"
                                data-dismiss="modal">Cancel</button>
                                <button class="btn btn-primary" style="width: 49.6%;">
                                    Add Comment
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div> 
        <?php if(!empty($item)): ?>

            
            <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" >
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Delete!</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                        <h5>Do you want to delete this comment?</h5>
                        </div>
                        <div class="modal-footer">
                            <form action="<?php echo e(route('comments.destroy', $item->id)); ?>" id="mDelete" method="post">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div> 

            
            <div class="modal fade" id="showModal" tabindex="-1" role="dialog" >
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">View!</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="text-right">
                                <small id="created"></small>
                            </div>
                            <p id="body"></p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" 
                                data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
            
            
            <div class="modal fade" id="editModal" tabindex="-1" role="dialog" >
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Update!</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form action="" id="mUpdate" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field("put"); ?>
                                <div class="form-group">
                                    <textarea placeholder="Comment" name="body" 
                                        id="body"
                                        style="resize: none;" 
                                        cols="30" 
                                        rows="10"
                                        class="form-control"></textarea>
                                </div>
                                <div class="form-group">
                                    <button type="button" class="btn btn-secondary" style="width: 49.6%;" 
                                    data-dismiss="modal">Cancel</button>
                                    <button class="btn btn-primary" style="width: 49.6%;">
                                        Update Comment</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        <?php else: ?> 
            <h4 class="text-center">No Comment here!</h4>
        <?php endif; ?>

    <?php endif; ?> 
           

</div>

<?php $__env->stopSection(); ?>
        
<?php echo $__env->make('pages.blog', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>