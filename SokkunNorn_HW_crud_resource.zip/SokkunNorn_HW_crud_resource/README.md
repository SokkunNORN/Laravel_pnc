
############ set up project #############

connect database !!!!!!!
1. create database
2. open file .env 
3. input your database name in line 12 name DB_DATABASE
4. in line 13 input user name root

create table in database !!!!!!
1. open terminal 
2. run command php artisan migrate

insert dummy data !!!!!!!!!!
open terminal then run command php artisan db:seed

!!!!!!!!your project setup already.!!!!!!!!!!






