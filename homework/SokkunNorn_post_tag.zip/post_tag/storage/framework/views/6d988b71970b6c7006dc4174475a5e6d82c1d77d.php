<?php $__env->startSection('content'); ?>

    <a href="<?php echo e(route("tag.create")); ?>" class="text-primary">
        <i class="material-icons">control_point</i>
    </a>
    <hr>    
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Name</th>
                <th>Created</th>
                <th>Updated</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $tag; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->content); ?></td>
                    <td><?php echo e($item->created_at); ?></td>
                    <td><?php echo e($item->updated_at); ?></td>
                    <td>        
                        <a href="<?php echo e(route('tag.edit',$item->id)); ?>" class="text-primary">
                            <i class="material-icons">edit</i>
                        </a>
                        <a href="#mDelete" data-toggle="modal" data-id="<?php echo e($item->id); ?>" 
                            data-content="<?php echo e($item->content); ?>" class="text-danger">
                            <i class="material-icons">delete</i>
                        </a>
                    </td>
                </tr>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </tbody>
    </table>

    <!-- Modal -->
    <div class="modal fade" id="mDelete" tabindex="-1" role="dialog" 
        aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Delete</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <p id="content"></p>
            </div>
            <div class="modal-footer">
                <form action="" id="delete" method="post">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo csrf_field(); ?>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </div>
          </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>