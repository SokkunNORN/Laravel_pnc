<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-4"></div>
        <div class="col-4">
            <a href="<?php echo e(route('post.index')); ?>" class="text-danger">
                <i class="material-icons">arrow_back</i>
            </a>
            <hr>
            <div class="card p-3">
                <div class="card-body">
                    <h4>Update Post</h4>
                    <hr>                    
                    <form method="post" action="<?php echo e(route('post.update', $post->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        <div class="form-group">
                            <input type="text" placeholder="title"
                                value="<?php echo e($post->title); ?>" name="title" class="form-control">
                        </div>
                        <div class="form-group">
                            <textarea name="body" class="form-control" placeholder="Content" 
                                style="resize:none;" id="" cols="30" rows="10"><?php echo e($post->body); ?>

                            </textarea>
                        </div>
                        <?php $__currentLoopData = $post->tags()->pluck('content'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" 
                                    value="<?php echo e($item); ?>" checked> <?php echo e($item); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-group mt-3">
                            <button class="btn btn-primary">Save Post</button>
                        </div>        
                    </form>
                </div>
            </div>
        </div>
    </div>
            
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>