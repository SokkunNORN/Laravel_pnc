<?php $__env->startSection('content'); ?>

    <a href="<?php echo e(route('post.create')); ?>" class="text-primary">
        <i class="material-icons">control_point</i>
    </a>
    <hr>
    <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
    
    <div class="card m-3 shadow-sm">
        <div class="card-body">
            <div class="text-right">
                <small><?php echo e($item->created_at->diffForHumans()); ?></small>
            </div>
            <h4><?php echo e($item->title); ?></h4>
            <p><?php echo e($item->body); ?></p>
            <div class="text-right">
                <?php $__currentLoopData = $item->tags->pluck('content'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                    
                    <small class="bg-primary p-1 text-white"><?php echo e($tag); ?></small>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="card-footer text-right">
            
            <a href="<?php echo e(route('post.edit', $item->id)); ?>" class="text-primary">
                <i class="material-icons">edit</i>
            </a>
            <a href="#mDeletePost" data-toggle="modal" data-id="<?php echo e($item->id); ?>" 
                data-title="<?php echo e($item->title); ?>" class="text-danger">
                <i class="material-icons">delete</i>
            </a>
        </div>
    </div>
    


    <div class="modal fade" id="mDeletePost">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Delete post</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p id="title"></p>
            </div>
            <div class="modal-footer">
                <form action="" id="deletePost" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submiy" class="btn btn-danger">Delete</button>
                </form>
            </div>
            </div>
        </div>
    </div>


    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>