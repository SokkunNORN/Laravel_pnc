
<footer class="page-footer font-small bg-success">

    <div class="footer-copyright text-center py-3">© 2019_wep Copyright:
        <a href="#!" class="text-white"> Student_PN</a>
    </div>

</footer>