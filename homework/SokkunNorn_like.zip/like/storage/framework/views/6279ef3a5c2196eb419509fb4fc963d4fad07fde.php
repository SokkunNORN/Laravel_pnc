<?php $__env->startSection('content'); ?>

    <div class="container">
        <h2>Post</h2>
        <a href="<?php echo e(route('post.create')); ?>" class="text-primary">
            <i class="material-icons">control_point</i>
        </a>
        <hr>
        <div class="row">
            <div class="col-3"></div>
            <div class="col-6">

                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <small class="float-right"><?php echo e($item['created_at']->diffForHumans()); ?></small>
                            <h3><?php echo e($item['title']); ?></h3>
                            <hr>
                            <p>
                                <?php echo e($item['content']); ?>

                                <form action="<?php echo e(route('post.destroy',$item->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button class="btn btn-sm float-right text-danger">
                                        <i class="material-icons">delete</i>
                                    </button>
                                </form>
                            </p>
                            <hr>
                            <a href="#!" class="text-secondary">
                                <i class="material-icons">thumb_up</i>
                            </a>
                            <span class="ml-3"><?php echo e($numberUser); ?> .like</span>
                        </div>
                    </div>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <div class="col-3"></div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>